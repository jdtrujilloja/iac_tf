var AWS = require('aws-sdk');
exports.handler = function(event, context) {
    var ec2 = new AWS.EC2({region: 'us-east-1'});
    ec2.startInstances({InstanceIds : ['i-07dfcccab8d25ec83', 'i-0bb0bac2af276e9f4', 'i-0059c672f3050d6cf', 'i-037cadf8b84faff5f', 'i-0ac7b4caf4c652259'] },function (err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else console.log(data); // successful response
        context.done(err,data);
    });
};